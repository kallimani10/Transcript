import streamlit as st
from googletrans import Translator
import docx
import os

# Load translator
translator = Translator()

st.set_page_config(page_title="📄 Multilingual Text Transcriber", layout="centered")
st.title("🌐 Multilingual Text Translator from Transcript File")

st.markdown("""
Upload a **text transcript** in any language. This app will:
- Detect the language
- Translate the text into **multiple selected languages**
""")

# Language options
language_options = {
    # Indian Languages
    "Hindi": "hi",
    "Telugu": "te",
    "Tamil": "ta",
    "Kannada": "kn",
    "Malayalam": "ml",
    "Bengali": "bn",
    "Marathi": "mr",
    "Gujarati": "gu",
    "Punjabi": "pa",
    "Urdu": "ur",
    "Assamese": "as",
    "Odia": "or",
    "Sanskrit": "sa",
    "Nepali": "ne",
    "Maithili": "mai",
    "Sindhi": "sd",
    "Bhojpuri": "bho",
    "Konkani": "kok",
    "Manipuri": "mni",
    "Kashmiri": "ks",

    # International Languages
    "English": "en",
    "French": "fr",
    "German": "de",
    "Spanish": "es",
    "Japanese": "ja",

    # Not supported
    "Haryanvi (Not Supported)": None
}

unsupported_languages = ["Haryanvi (Not Supported)"]

selected_languages = st.multiselect(
    "Choose output languages for translation:",
    list(language_options.keys()),
    default=["English", "Hindi", "French"]
)

uploaded_file = st.file_uploader("Upload a transcript file", type=["txt", "docx"])

def read_text(file):
    if file.name.endswith(".txt"):
        return file.read().decode("utf-8")
    elif file.name.endswith(".docx"):
        doc = docx.Document(file)
        return "\n".join([para.text for para in doc.paragraphs])
    else:
        return None

if uploaded_file and selected_languages:
    input_text = read_text(uploaded_file)

    if input_text:
        st.subheader("📄 Original Transcript")
        st.write(input_text)

        detected_lang = translator.detect(input_text).lang
        st.success(f"Detected language: `{detected_lang}`")

        st.subheader("🌐 Translations")

        for lang in selected_languages:
            dest_code = language_options[lang]

            if dest_code is None:
                st.warning(f"{lang} is not supported by Google Translate yet.")
                continue

            translated = translator.translate(input_text, dest=dest_code)
            st.markdown(f"**{lang}:**")
            st.code(translated.text)
    else:
        st.error("Unsupported file format or empty file.")
